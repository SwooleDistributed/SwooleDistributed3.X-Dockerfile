#ifndef DS_DEQUE_HANDLERS_H
#define DS_DEQUE_HANDLERS_H

#include "php.h"

extern zend_object_handlers php_deque_handlers;

void php_ds_register_deque_handlers();

#endif
